#include "stdafx.h"
#include "Player.h"
#include "SceneGame.h"
#include "Bullet.h"
Player::Player(const std::string& name)
	:GameObject(name)
{
}

void Player::Init()
{
	sortingLayer = SortingLayers::ForeGround;
	sortingOrder = 0;
}

void Player::Release()
{
}


void Player::Reset()
{
	playerSp.setTexture(TEXTURE_MGR.Get(texId) , true);
	SetOrigin(Origins::MC);
	SetPosition({0.f , 0.f});
	SetRotation(0.f);

	dir = { 0.f , 0.f };
	look = { 1.0f , 0.f };

	if (SCENE_MGR.GetCurrentSceneId() == SceneIds::Game) {
		sceneGame = (SceneGame*)SCENE_MGR.GetCurrentScene();
	}
	else {
		sceneGame = nullptr;
	}
	
	for (auto bullet : bulletlist) {
		bullet->SetActive(false);
		bulletPool.push_back(bullet);
	}
	bulletlist.clear();
}

void Player::Update(float dt)
{
	auto iter = bulletlist.begin();
	while (iter != bulletlist.end()) {
		if (!(*iter)->GetActive()) {
			bulletPool.push_back((*iter));
			iter = bulletlist.erase(iter);
		}
		else {
			iter++;
		}
	}

	dir.x = InputMgr::GetAxis(Axis::Horizontal);
	dir.y = InputMgr::GetAxis(Axis::Vertical);

	if (Utils::Magnitude(dir) > 1.f) {
		Utils::Normalize(dir);
	}

	SetPosition(position + dir * speed * dt);

	sf::Vector2f pos = GetPosition();
	sf::Vector2i mousePos = InputMgr::GetMousePosition();
	sf::Vector2f mouseWorldPos = sceneGame->ScreenToWorld(mousePos);
	look = Utils::GetNormal(mouseWorldPos - GetPosition());

	SetRotation(Utils::Angle(look));

	hitBox.UpdateTransform(playerSp, GetLocalBounds());

	if (InputMgr::GetMouseButtonDown(sf::Mouse::Left)) {
		Shoot();
	}
}

void Player::Draw(sf::RenderWindow& window)
{
	window.draw(playerSp);
	hitBox.Draw(window);
}

void Player::SetPosition(const sf::Vector2f& pos)
{
	position = pos;
	playerSp.setPosition(pos);
}

void Player::SetScale(const sf::Vector2f& s)
{
	scale = s;
	playerSp.setScale(s);
}

void Player::SetOrigin(Origins preset)
{
	originPreset = preset;
	Utils::SetOrigin(playerSp, originPreset);
}

void Player::SetOrigin(const sf::Vector2f& o)
{
	originPreset = Origins::Custom;
	origin = o;
	playerSp.setOrigin(o);
}

void Player::SetRotation(float rot)
{
	rotation = rot;
	playerSp.setRotation(rot);
}

void Player::Shoot()
{
	Bullet* bullet = nullptr;
	if (bulletPool.empty()) {
		bullet = new Bullet();
		bullet->Init();
	}
	else {
		bullet = bulletPool.front();
		bulletPool.pop_front();
	}
	bullet->Reset();
	bullet->Fire(position + look * 10.f, look, 1000.f, 100);
	bullet->SetActive(true);

	bulletlist.push_back(bullet);
	sceneGame->AddGameObject(bullet);
}
