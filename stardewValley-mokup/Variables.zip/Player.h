#pragma once
#include "GameObject.h"
#include "HitBox.h"

class SceneGame;
class Bullet;

class Player : public GameObject
{
protected:
    std::string texId = "graphics/player.png";
    sf::Sprite playerSp;

    sf::Vector2f dir;
    sf::Vector2f look;

    float speed = 500.f;

    SceneGame* sceneGame = nullptr;

    HitBox hitBox;
    
    std::list<Bullet*> bulletlist;
    std::list<Bullet*> bulletPool;

public:
    Player(const std::string& name);
    ~Player() override = default;
    // GameObject��(��) ���� ��ӵ�
    void Init() override;
    void Release() override;
    void Reset() override;
    void Update(float dt) override;
    void Draw(sf::RenderWindow& window) override;

    void SetPosition(const sf::Vector2f& pos) override;
    void SetScale(const sf::Vector2f& s) override;
    void SetOrigin(Origins preset) override;
    void SetOrigin(const sf::Vector2f& o) override;
    void SetRotation(float rot) override;

    sf::FloatRect GetLocalBounds() const override {
        return playerSp.getLocalBounds();
    };
    sf::FloatRect GetGlobalBounds() const override {
        return playerSp.getGlobalBounds();
    };

    void Shoot();
};

