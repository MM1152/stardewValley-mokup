#include "stdafx.h"
#include "Zombie.h"
#include "Player.h"


Zombie::Zombie(const std::string& name)
	:GameObject(name)
{
}

void Zombie::SetPosition(const sf::Vector2f& pos)
{
	position = pos;
	body.setPosition(pos);
}

void Zombie::SetRotation(float rot)
{
	rotation = rot;
	body.setRotation(rot);
}

void Zombie::SetScale(const sf::Vector2f& s)
{
	scale = s;
	body.setScale(s);
}

void Zombie::SetOrigin(const sf::Vector2f& o)
{
	origin = o;
	originPreset = Origins::Custom;
	body.setOrigin(o);
}

void Zombie::SetOrigin(Origins preset)
{
	originPreset = preset;
	Utils::SetOrigin(body, originPreset);
}

void Zombie::Init()
{
	sortingLayer = SortingLayers::ForeGround;
	sortingOrder = 0;

	SetType(type);
}

void Zombie::Release()
{
}

void Zombie::Reset()
{
	player = (Player*)SCENE_MGR.GetCurrentScene()->FindGameObject("Player");

	body.setTexture(TEXTURE_MGR.Get(texId) , true);
	SetOrigin(Origins::MC);
	SetPosition({0.f , 0.f});
	SetRotation(0.f);
	SetScale({ 1.f , 1.f });
}

void Zombie::Update(float dt)
{
	

	sf::Vector2f dir = player->GetPosition() - GetPosition();
	Utils::Normalize(dir);
	if (Utils::Magnitude(player->GetPosition() - GetPosition()) > 10.f) {
		SetPosition(GetPosition() + dir * speed * dt);
	}
	SetRotation(Utils::Angle(dir));

	hitbox.UpdateTransform(body, GetLocalBounds());
}

void Zombie::Draw(sf::RenderWindow& window)
{
	window.draw(body);
	hitbox.Draw(window);
}

void Zombie::SetType(Types type)
{
	this->type = type;

	switch (this->type) {
	case Types::Bloater:
		texId = "graphics/bloater.png";
		maxHp = 300;
		speed = 100.f;
		damage = 50.f;
		attackInterval = 1.f;
		hp = maxHp;
		break;
	case Types::Chaser:
		texId = "graphics/chaser.png";
		maxHp = 200;
		speed = 200.f;
		damage = 100.f;
		attackInterval = 1.f;
		hp = maxHp;
		break;
	case Types::Crawler:
		texId = "graphics/crawler.png";
		maxHp = 100;
		speed = 300.f;
		damage = 150.f;
		attackInterval = 1.f;
		hp = maxHp;
		break;
	}
}
